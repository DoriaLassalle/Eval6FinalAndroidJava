package com.example.evalfinalandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText email, password;
    private Button btnEntrar, btnAbout, btnRegistrarse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        btnEntrar = findViewById(R.id.entrar);
        btnAbout = findViewById(R.id.about);
        btnRegistrarse = findViewById(R.id.registrarse);

        btnAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent irAbout = new Intent(getApplicationContext(), About.class);
                startActivity(irAbout);
            }
        });
        btnRegistrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent registrar = new Intent(getApplicationContext(), Registro.class);
                startActivity(registrar);
            }
        });
        btnEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (email.getText().toString().isEmpty() || password.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Debe completar ambos datos.",
                            Toast.LENGTH_SHORT).show();
                } else if (!email.getText().toString().contains("@")) {
                    Toast.makeText(getApplicationContext(), "Debe ingresar un email válido.",
                            Toast.LENGTH_SHORT).show();
                } else if (password.getText().toString().length() < 8 || password.getText().
                        toString().length() > 8) {
                    Toast.makeText(getApplicationContext(), "La contraseña debe tener 8 dígitos",
                            Toast.LENGTH_SHORT).show();
                } else {
                    Intent irHome = new Intent(getApplicationContext(), HomeActivity.class);
                    startActivity(irHome);
                }

            }
        });
    }
}