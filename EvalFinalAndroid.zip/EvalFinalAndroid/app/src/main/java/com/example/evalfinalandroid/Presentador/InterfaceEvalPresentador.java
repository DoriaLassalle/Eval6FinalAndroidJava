package com.example.evalfinalandroid.Presentador;

public interface InterfaceEvalPresentador {

                //llevo al modelo vengo de la vista
    void vistaPresentador(String montoCalcular, String montoSueldo,
                          String valor,String accid,String age,String modelo);


                 //devuelvo al presentador para la vista
    void devuelvePresentador(double dolares, double euros, double libras, double yen,
                             double multaFinal, double totalPoliza);

}
