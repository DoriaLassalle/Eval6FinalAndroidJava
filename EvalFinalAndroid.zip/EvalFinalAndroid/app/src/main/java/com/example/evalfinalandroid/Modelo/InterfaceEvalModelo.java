package com.example.evalfinalandroid.Modelo;

public interface InterfaceEvalModelo {

                    //recibo del presentador que viene de la vista
    void vistaPresentador(String montoCalcular, String montoSueldo,
                          String valor,String accid,String age,String modelo);

}
