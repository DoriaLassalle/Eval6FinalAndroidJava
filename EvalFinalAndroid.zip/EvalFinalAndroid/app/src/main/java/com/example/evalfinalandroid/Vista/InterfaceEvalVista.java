package com.example.evalfinalandroid.Vista;

public interface InterfaceEvalVista {

                     //recibo del presentador que viene del modelo para mostrar
    void devuelvePresentador(double dolares, double euros, double libras, double yen,
                             double multaFinal, double totalPoliza);

}
